// 信贷API测试地址
// export const API_XD_SERVER = 'http://172.16.200.104:8084/apitest/api/wechat/doold' 

// 汽车API测试地址
// export const API_CAR_SERVER = 'http://10.110.1.145:30677/open/carAuction/'

// 微信API测试地址
// export const API_WX_SERVER = 'http://172.16.200.110:31006/'
// export const API_WX_SERVER = 'http://172.16.200.112:30111/wx/app/'
// export const API_WX_SERVER = 'http://192.168.14.29:31006/'

// 测试地址 http://172.16.200.112:30111/wx/app/ 
// 正式地址：http://120.77.168.38:30111/wx/app/
export const API_WX_SERVER = 'http://172.16.200.112:30111/wx/app/'

