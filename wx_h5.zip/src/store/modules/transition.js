let state = {
    transitionName: '',
    action: []
}

const mutations = {
    setTransition(state, transition) {
        state.transitionName = transition;
    }
}

export default {
    state,
    mutations
}