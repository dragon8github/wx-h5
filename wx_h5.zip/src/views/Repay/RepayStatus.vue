<template>
 <div id="">
      
 </div>
</template>

<script>
  import mtField from '@components/field/field.vue'
  import Toast   from '@components/toast/index.js'
  import Loader  from '@components/loader/index.js'
  export default {
        name: 'Login',
        data () {
            return {
            
            }
        },
        watch: {
            
        },
        methods: {
            
        },
        components: {
        }
  }
</script>


<style scoped lang="scss">
@import "~@sass/_variables";
@import "~@sass/_func";


</style>
